<?php

/*
 * @version		$Id: default_comments.php 2.1.0 2013-06-18 $
 * @package		Joomla
 * @copyright   Copyright (C) 2012-2014 MrVinoth
 * @license     GNU/GPL http://www.gnu.org/licenses/gpl-2.0.html
*/

defined('_JEXEC') or die('Restricted access');

$config = $this->config;
$custom = $this->custom;
$video = $this->video;
$comments = JPATH_SITE . DS .'components' . DS . 'com_jcomments' . DS . 'jcomments.php';
  
if(file_exists($comments) && $config[0]->comments_type == 'jcomments') {
	require_once($comments);
    echo JComments::showComments($video->id, 'com_allvideoshare', $video->title);
}

?>

<?php if($config[0]->comments_type == 'facebook') : ?>
	<div class="avs_video_comments">
  		<h2><?php echo JText::_('ADD_YOUR_COMMENTS'); ?></h2>
  		<div class="fb-comments" data-href="<?php echo JURI::getInstance()->toString(); ?>" data-num-posts="<?php echo $config[0]->comments_posts; ?>" data-width="<?php echo $custom->width; ?>" data-colorscheme="<?php echo $config[0]->comments_color; ?>"></div>
	</div>
<?php endif;