<?php

/*
 * @version		$Id: default_all.php 2.1.0 2013-06-18 $
 * @package		Joomla
 * @copyright   Copyright (C) 2012-2013 MrVinoth
 * @license     GNU/GPL http://www.gnu.org/licenses/gpl-2.0.html
*/

defined('_JEXEC') or die('Restricted access');

echo $this->loadTemplate( 'comments' ); 
echo $this->loadTemplate( 'relatedvideos' );