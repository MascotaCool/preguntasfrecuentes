/*
 * @version		$Id: allvideoshare.js 2.1.0 2013-06-18 $
 * @package		Joomla
 * @copyright   Copyright (C) 2012-2013 MrVinoth
 * @license     GNU/GPL http://www.gnu.org/licenses/gpl-2.0.html
*/