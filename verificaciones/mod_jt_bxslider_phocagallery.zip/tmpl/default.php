<?php
/*
# ------------------------------------------------------------------------
# Templates for Joomla 2.5 - Joomla 3.5
# ------------------------------------------------------------------------
# Copyright (C) 2011-2013 Jtemplate.ru. All Rights Reserved.
# @license - PHP files are GNU/GPL V2.
# Author: Makeev Vladimir
# Websites:  http://www.jtemplate.ru 
# ---------  http://code.google.com/p/jtemplate/   
# ------------------------------------------------------------------------
*/
// no direct access
defined('_JEXEC') or die;
if ($jt_load_scripts == 2) { 
	if ($jt_load_jquery > 0) { 
		echo '<script src="http://ajax.googleapis.com/ajax/libs/jquery/'.$jt_jquery_ver.'/jquery.min.js" type="text/javascript"></script>';
		} 
	if ($jt_load_easing > 0) {
		echo '<script type = "text/javascript" src = "'.JURI::root().'/modules/mod_jt_bxslider_phocagallery/js/jquery.easing.1.3.js"></script>';
		}
	if ($jt_load_bxslider > 0) {
		echo '<script type = "text/javascript" src = "'.JURI::root().'/modules/mod_jt_bxslider_phocagallery/js/jquery.bxslider.min.js"></script>';
		}
	echo '<script type = "text/javascript">if (jQuery) jQuery.noConflict();</script>';
}

?>

<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('#bxslider_phocagallery<?php echo $jt_id; ?>').bxSlider({
		mode: '<?php echo $jt_mode;?>',
		randomStart: <?php echo $jt_random_start;?>,
		minSlides: <?php echo $jt_min_slides;?>,
		maxSlides: <?php echo $jt_max_slides;?>,
		slideWidth: <?php echo $jt_slide_width;?>,
		slideMargin: <?php echo $jt_slide_margin;?>,
		adaptiveHeight: <?php echo $jt_adaptive_height;?>,
		adaptiveHeightSpeed: <?php echo $jt_adaptive_height_speed;?>,
		//ticker: <?php echo $jt_ticker;?>,
		//tickerHover: <?php echo $jt_ticker_hover;?>,
		speed: <?php echo $jt_speed;?>,
		controls: <?php echo $jt_controls; ?>,
		auto: <?php echo $jt_auto;?>,
		autoControls: <?php echo $jt_auto_controls;?>,
		pause: <?php echo $jt_pause?>,
		autoDelay: <?php echo $jt_auto_delay; ?>,
		autoHover: <?php echo $jt_autohover; ?>,
		pager: <?php echo $jt_pager;?>,
		captions: <?php echo $jt_title;?>,
		pagerType: '<?php echo $jt_pager_type;?>',
		pagerShortSeparator: '<?php echo $jt_pager_saparator;?>'
	});
});
</script>

<div class="mod_jt_bxslider_phocagallery <?php echo $moduleclass_sfx ?>">	
	<ul id="bxslider_phocagallery<?php echo $jt_id; ?>">	
		<?php
		if (count($images) > 0) {
			foreach ($images as $k => $v) {	
				$title = '';
				if ($v->title != '' && $jt_title == 'true') {
					$title = 'title="'.strip_tags(htmlspecialchars($v->title)).'"';
				}		
				if (isset($v->extl) &&  $v->extl != '') {
					echo '<li><img src="'.PhocaGalleryText::strTrimAll($v->extl).'" alt="'.htmlspecialchars($v->title).'"  '.$title.' /></li>';
				} else {
					$thumbLink	= PhocaGalleryFileThumbnail::getThumbnailName($v->filename, 'large');
					echo '<li><img src="'.JURI::base(true).'/'.$thumbLink->rel.'" alt="'.htmlspecialchars($v->title).'"  '.$title.' /></li>';
				}				
			}
		}				
		?>
	</ul>	
<div style="clear:both;"></div>
</div>

