<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once( dirname(__FILE__).DS.'helper.php' );
$twitterfollowerbox = modTwitterFollowerbox::getTwitterFollowerbox( $params);
require( JModuleHelper::getLayoutPath( 'mod_twitterslider' ) );



?>