DROP TABLE IF EXISTS `#__accordiongallery`;
DROP TABLE IF EXISTS `#__accordiongalleryc`;