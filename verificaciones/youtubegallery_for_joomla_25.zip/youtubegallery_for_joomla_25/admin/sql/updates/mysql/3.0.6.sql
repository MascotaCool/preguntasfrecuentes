ALTER TABLE `#__youtubegallery_themes` ADD COLUMN `nocookie` tinyint(1) NOT NULL default 0;
