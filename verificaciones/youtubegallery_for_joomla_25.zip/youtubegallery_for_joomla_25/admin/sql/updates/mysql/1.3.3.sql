ALTER TABLE `#__youtubegallery` ADD COLUMN `customlimit` smallint(6) NOT NULL;
