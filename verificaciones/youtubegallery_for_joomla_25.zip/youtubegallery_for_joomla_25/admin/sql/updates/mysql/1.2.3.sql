
ALTER TABLE `#__youtubegallery` ADD COLUMN `pagination` smallint(6) NOT NULL;


