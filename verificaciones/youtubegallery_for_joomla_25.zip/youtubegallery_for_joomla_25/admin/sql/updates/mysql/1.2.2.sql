
ALTER TABLE `#__youtubegallery` ADD COLUMN `hrefaddon` varchar(255) NOT NULL;


