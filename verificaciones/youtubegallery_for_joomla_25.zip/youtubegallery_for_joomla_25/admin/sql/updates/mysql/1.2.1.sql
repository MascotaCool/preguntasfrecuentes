
ALTER TABLE `#__youtubegallery` ADD COLUMN `openinnewwindow` tinyint(1) NOT NULL;

ALTER TABLE `#__youtubegallery` ADD COLUMN `rel` varchar(255) NOT NULL;



