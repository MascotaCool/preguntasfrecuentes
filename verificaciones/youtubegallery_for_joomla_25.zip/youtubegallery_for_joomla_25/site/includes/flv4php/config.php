<?php
/**
 * @Copyright 2006 Iv�n Montes
 * @GNU General Public License
 **/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');


$config['db_host'] = "localhost";
$config['db_username'] = "username";
$config['db_password'] = "************";
$config['db_name'] = "Database_name";
$config['db_table_prefix'] = "flv_";
$config['block_counter'] = 0;
?>