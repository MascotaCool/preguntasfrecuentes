<?php
/**
 * YoutubeGallery Joomla! 2.5 Native Component
 * @version 3.4.4
 * @author DesignCompass corp< <support@joomlaboat.com>
 * @link http://www.joomlaboat.com
 * @GNU General Public License
 **/


// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controller library
jimport('joomla.application.component.controller');
 
/**
 * YoutubeGallery Component Controller
 */
class YoutubeGalleryController extends JController
{
}


?>