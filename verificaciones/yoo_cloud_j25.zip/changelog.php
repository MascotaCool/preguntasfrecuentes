<?php
/**
* @package   yoo_cloud
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

// no direct access
die('Restricted access');

?>

Changelog
------------

1.0.7
^ Updated menu icons and titles according to Warp 6.2

1.0.6
# Fixed form styling

1.0.5
^ Changed tag cloud CSS

1.0.4
+ Added Facebook social button

1.0.3
#Fixed menu-dropdown level1 color

1.0.2
^ Changed system paths according to Warp 6.1.2 (J17 + WP)

1.0.1
^ Updated to Warp 6.1
# Fixed bold font for Chrome/Safari
# Fixed menu-dropdown level2 color
# Fixed CSS3 Animations
# Fixed module badges for RTL

1.0.0
+ Initial Release



* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note